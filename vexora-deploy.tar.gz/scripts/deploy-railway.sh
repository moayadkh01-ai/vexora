#!/bin/bash
# ============================================================
# VEXORA — deploy to Railway (permanent 24/7, WebSockets + volumes)
# Prerequisite: the user created a Railway project and gave us a
# Project Token (Settings → Tokens → Publish). Export it first:
#     export RAILWAY_TOKEN=<project token>
# Then run this script. First run creates the service + volume.
# ============================================================
set -euo pipefail
[ -n "${RAILWAY_TOKEN:-}" ] || { echo "RAILWAY_TOKEN is not set — see DEPLOY.md"; exit 1; }
HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE"

if [ ! -x node_modules/.bin/railway ]; then
  npm install -D --no-save @railway/cli >/dev/null 2>&1 || npx -y railway@latest --version
fi
RY="node_modules/.bin/railway"; [ -x "$RY" ] || RY="npx -y railway"

echo "▶ deploying to Railway…"
"$RY" up --ci --non-interactive 2>&1 | tail -20
echo ""
echo "▶ attach a persistent volume once (service → Settings → Volumes):"
echo "    mount path: /data   →  then set variable DB_PATH=/data/vexora.db"
echo "▶ set variables in the Railway dashboard (or CLI):"
echo "    NODE_ENV=production  COOKIE_SECURE=1  ADMIN_PASS=<strong password>"
echo "▶ your permanent URL: Railway → Settings → Networking → Generate Domain"
